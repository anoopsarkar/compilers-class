void greet();
int main () {
  greet();
}
