#include <stdio.h>
void greet () {
  printf("세상, 안녕!\n");
}
